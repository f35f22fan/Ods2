#include "OfficeSpreadsheet.hpp"

#include "TableCalculationSettings.hpp"
#include "../Sheet.hpp"
#include "TableNamedExpressions.hpp"
#include "TableNamedRange.hpp"

#include "../Ns.hpp"
#include "../ns.hxx"
#include "../Tag.hpp"

#include "../ndff/Container.hpp"
#include "../ndff/Property.hpp"

namespace ods::inst {

OfficeSpreadsheet::OfficeSpreadsheet(Abstract *parent, Tag *tag, ndff::Container *cntr)
: Abstract(parent, parent->ns(), id::OfficeSpreadsheet)
{
	if (cntr)
		Init(cntr);
	else if (tag)
		Init(tag);
	else
		InitDefault();
}

OfficeSpreadsheet::OfficeSpreadsheet(const OfficeSpreadsheet &cloner)
: Abstract(cloner)
{}

OfficeSpreadsheet::~OfficeSpreadsheet()
{
	delete table_calculation_settings_;
	delete named_expressions_;
	
	for (auto *next: tables_)
		delete next;
}

Abstract*
OfficeSpreadsheet::Clone(Abstract *parent) const
{
	auto *p = new OfficeSpreadsheet(*this);
	
	if (parent != nullptr)
		p->parent(parent);
	
	if (table_calculation_settings_ != nullptr)
	{
		p->table_calculation_settings_ = (TableCalculationSettings*)
			table_calculation_settings_->Clone(p);
	}
	
	if (named_expressions_ != nullptr)
	{
		p->named_expressions_ = (TableNamedExpressions*)
			named_expressions_->Clone(p);
	}
	
	for (auto *next: tables_)
	{
		p->tables_.append((ods::Sheet*)next->Clone(p));
	}
	
	return p;
}

ods::Sheet*
OfficeSpreadsheet::GetSheet(const int index) const
{
	if (index >= tables_.size())
		return nullptr;
	
	return tables_[index];
}

ods::Sheet*
OfficeSpreadsheet::GetSheet(QStringView name) const
{
	if (name.isEmpty())
		return nullptr;
	
	for (auto *sheet: tables_)
	{
		if (sheet->name() == name)
			return sheet;
	}
	
	return nullptr;
}

void OfficeSpreadsheet::Init(ndff::Container *cntr)
{
	using Op = ndff::Op;
	ndff::Property prop;
	Op op = cntr->Next(prop, Op::TS);
	if (op == Op::N32_TE)
		return;

	if (op == Op::TCF_CMS)
		op = cntr->Next(prop, op);

	while (true)
	{
		if (op == Op::TS)
		{
			if (prop.is(ns_->table()))
			{
				if (prop.name == ns::kTable)
					tables_.append(new ods::Sheet(this, 0, cntr));
				else if (prop.name == ns::kCalculationSettings)
					table_calculation_settings_ = new TableCalculationSettings(this, 0, cntr);
				else if (prop.name == ns::kNamedExpressions) {
					named_expressions_ = new TableNamedExpressions(this, 0, cntr);
					for (TableNamedRange *nr: named_expressions_->named_ranges()) {
						nr->global(true);
					}
				}
			}
		} else if (ndff::is_text(op)) {
			Append(cntr->NextString());
		} else {
			break;
		}
		op = cntr->Next(prop, op);
	}

	if (op != Op::SCT)
		mtl_trace("Unexpected op: %d", op);
}

void OfficeSpreadsheet::Init(Tag *tag)
{
	Scan(tag);
}

void OfficeSpreadsheet::InitDefault()
{
	table_calculation_settings_ = new TableCalculationSettings(this);
	named_expressions_ = new TableNamedExpressions(this);
}

void OfficeSpreadsheet::ListChildren(QVector<StringOrInst*> &vec,
	const Recursively r)
{
	if (table_calculation_settings_)
	{
		vec.append(new StringOrInst(table_calculation_settings_, TakeOwnership::No));
		if (r == Recursively::Yes)
			table_calculation_settings_->ListChildren(vec, r);
	}
	
	for (auto *table: tables_)
	{
		vec.append(new StringOrInst(table, TakeOwnership::No));
		if (r == Recursively::Yes)
			table->ListChildren(vec, r);
	}
	
	if (named_expressions_)
	{
		vec.append(new StringOrInst(named_expressions_, TakeOwnership::No));
		if (r == Recursively::Yes)
			named_expressions_->ListChildren(vec, r);
	}
}

void OfficeSpreadsheet::ListKeywords(inst::Keywords &list, const inst::LimitTo lt)
{
	inst::AddKeywords({tag_name()}, list);
}

void OfficeSpreadsheet::ListUsedNamespaces(NsHash &list)
{
	Add(ns_->office(), list);
}

ods::Sheet*
OfficeSpreadsheet::NewSheet(QString name)
{
	if (name.contains('\'')) {
		mtl_warn("Sheet names can't contain \'");
		return nullptr;
	}
	
	if (GetSheet(name) != nullptr)
		return nullptr;
	
	auto *sheet = new ods::Sheet(this);
	sheet->name(name);
	tables_.append(sheet);
	
	return sheet;
}

void OfficeSpreadsheet::Scan(Tag *tag)
{
	for (auto *x: tag->nodes())
	{
		if (!x->is_tag())
			continue;
		
		auto *next = x->as_tag();
		
		if (next->Has(ns_->table())) {
			if (next->Has(ods::ns::kTable)) {
				tables_.append(new ods::Sheet(this, next));
			} else if (next->Has(ods::ns::kCalculationSettings)) {
				table_calculation_settings_ = new TableCalculationSettings(this, next);
			} else if (next->Has(ods::ns::kNamedExpressions)) {
				named_expressions_ = new TableNamedExpressions(this, next);
				for (TableNamedRange *nr: named_expressions_->named_ranges()) {
					nr->global(true);
				}
			} else {
				Scan(next);
			}
		} else {
			Scan(next);
		}
	}
}

void OfficeSpreadsheet::WriteData(QXmlStreamWriter &xml)
{
	Write(xml, table_calculation_settings_);
	
	for (auto *table: tables_)
		table->Write(xml);
	
	Write(xml, named_expressions_);
}

} // ods::inst::
