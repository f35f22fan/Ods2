#pragma once

namespace ods { // ods::
namespace country { // ods::country::

const auto Brazil = QStringLiteral("BR");
const auto Canada = QStringLiteral("CA");
const auto China = QStringLiteral("CN");
const auto France = QStringLiteral("FR");
const auto Germany = QStringLiteral("DE");
const auto India = QStringLiteral("IN");
const auto Italy = QStringLiteral("IT");
const auto Luxembourg = QStringLiteral("LU");
const auto Pakistan = QStringLiteral("PK");
const auto Russia = QStringLiteral("RU");
const auto Spain = QStringLiteral("ES");
const auto Sweden = QStringLiteral("SE");
const auto Turkey = QStringLiteral("TR");
const auto UK = QStringLiteral("GB");
const auto USA = QStringLiteral("US");

} // ods::country::
} // ods::