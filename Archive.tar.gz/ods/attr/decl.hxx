#pragma once

namespace ods {
namespace attr {

class Border;
class FoFontStyle;
class FoFontWeight;
class StyleBorderLineWidth;
class StyleTextUnderlineColor;
class StyleTextUnderlineWidth;

}} // ods::attr::