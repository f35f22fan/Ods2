#pragma once

#include "../types.hxx"

namespace ods::ndff {
class CellNote;
class Container;
class FileEntryInfo;
class Property;

}
