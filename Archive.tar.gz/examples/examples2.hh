#pragma once

void CreateCurrency();
void ReadCurrency();

void CreateFormula();
void ReadFormula();

void CreateFormulaFunctions();

void CreateInvoice();









// personal:
void GenerateFunctionsListForGitHub();
void ReadCellRange();
